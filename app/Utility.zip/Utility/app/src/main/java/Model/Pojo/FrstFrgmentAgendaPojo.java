package Model.Pojo;

public class FrstFrgmentAgendaPojo {

    public String subtitleText;
    public String radioBtnText;

    public FrstFrgmentAgendaPojo(String subtitleText, String radioBtnText) {
        this.subtitleText = subtitleText;
        this.radioBtnText = radioBtnText;
    }

    public String getSubtitleText() {
        return subtitleText;
    }

    public void setSubtitleText(String subtitleText) {
        this.subtitleText = subtitleText;
    }

    public String getRadioBtnText() {
        return radioBtnText;
    }

    public void setRadioBtnText(String radioBtnText) {
        this.radioBtnText = radioBtnText;
    }
}
