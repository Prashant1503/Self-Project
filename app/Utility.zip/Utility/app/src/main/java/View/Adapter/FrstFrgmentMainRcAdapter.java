package View.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.utility.R;

import java.util.List;

import Model.Pojo.MainRcPojo;

import static Model.Pojo.MainRcPojo.AGENDA_LAYOUT;
import static Model.Pojo.MainRcPojo.JOURNAL_LAYOUT;

public class FrstFrgmentMainRcAdapter extends RecyclerView.Adapter {



    private List<MainRcPojo> mMainRcPojoslist;
    private Context mContext;

    public FrstFrgmentMainRcAdapter(List<MainRcPojo> mainRcPojoslist,Context ctx) {
       this.mMainRcPojoslist = mainRcPojoslist;
       this.mContext = ctx;
    }

    @Override
    public int getItemViewType(int position) {

        switch (mMainRcPojoslist.get(position).getViewType()) {

            case 1:

                return AGENDA_LAYOUT;

            case 2:
                return JOURNAL_LAYOUT;

            default:
                return -1;

        }
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        switch (viewType) {
            case AGENDA_LAYOUT:
                View agendaView = LayoutInflater.from(parent.getContext()).inflate(R.layout.frst_frgment_frst_layout,parent,false);

                return new agendaRecyclerViewHolder(agendaView);

            case JOURNAL_LAYOUT:

                View journalView = LayoutInflater.from(parent.getContext()).inflate(R.layout.frst_frgment_second_layout,parent,false);
                return new journalRecyclerViewHolder(journalView);


            default:
                    return null;
        }
    }
    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {

        switch (mMainRcPojoslist.get(position).getViewType()) {

            case AGENDA_LAYOUT:

                String goalcountertext = mMainRcPojoslist.get(position).getGoalCounterText();

                ((agendaRecyclerViewHolder) holder).setData(goalcountertext);


                break;

            case JOURNAL_LAYOUT:

                ((journalRecyclerViewHolder) holder).whtsinMindTextTvListner.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        Toast.makeText(mContext,"Clicked",Toast.LENGTH_SHORT).show();
                    }
                });


            default:
                return;



        }

    }

    @Override
    public int getItemCount() {
        return mMainRcPojoslist.size();
    }

//    view holder class.

    public class agendaRecyclerViewHolder extends RecyclerView.ViewHolder {

        AppCompatTextView agendaTitleTv,goalCounterTxtTv,addSomethingTv;


        public agendaRecyclerViewHolder(@NonNull View itemView) {
            super(itemView);

            agendaTitleTv = itemView.findViewById(R.id.agenda_title_tv);
            goalCounterTxtTv = itemView.findViewById(R.id.goal_counter_tv);
            addSomethingTv = itemView.findViewById(R.id.add_something_textView);

        }

        private void setData(String goalTitleText) {
            goalCounterTxtTv.setText(goalTitleText);
        }
    }

    public class journalRecyclerViewHolder extends RecyclerView.ViewHolder {

        AppCompatTextView journalTitleTv,whtsinMindTextTvListner;


        public journalRecyclerViewHolder(@NonNull View itemView) {
            super(itemView);

            journalTitleTv = itemView.findViewById(R.id.journal_title_textView);
            whtsinMindTextTvListner = itemView.findViewById(R.id.whts_inMind_textViewListner);

        }
//        private void setJournalData() {
//
//
//
//        }
    }




}
